===========================
GMS HINTERGRUND TOOL V 0.9
===========================

====================================
ACHTUNG BETA!!! NOCH NICHT FERTIG!!!
====================================

Warum?
- Nachdem die Schule im Frühjahr 2023 das setzen von eigenen
  Hintergrundbildern deaktiviert hat, habe ich dieses Tool geschrieben
  damit man sich wieder ein eigenes Hintergrundbild setzen kann.

Vorraussetzungen:
- Bild im Format .png (falls das Bild in einem anderen Format ist,
  kann das Bild auf folgender Webseite umgewandelt werden: https://t1p.de/4ctod)

Anleitung:
1. Kopiere dein Bild in diesen Ordner. Stelle sicher, dass es Hintergrund.png heißt.
2. Doppelklick auf das Programm Installieren.bat
3. Fertig. Jetzt wird das Hintergrundbild automatisch bei jeder anmeldung geladen.
   Das kann jedoch manchmal bis zu 5min dauern!

Deinstallation:
1. Doppelklick auf Deinstallieren.bat
2. Fertig. Jetzt ist das Programm gelöscht 
   und beim anmelden wird kein Hintergrundbild mehr gesetzt.

Von der Technischen Seite:
- Das Gespeicherte Hintergrundbild im Windows Cache wird ersetzt. 
  Dadurch kommt nach c.a. 2 - 5 Minuten ein neues. 
  Das wird durch die Batch Datei Autorun.bat getriggert.

Kontakt / Fehler Melden:

Discord (ALT Account*): K5G#2093

Readme.txt Version 1.00 (Nicht fertig)


*ALT = Alternative / 2. Account